# Rendered-PDF visual review — 2026-10-07

The actual final review PDFs were rendered with Poppler `pdftoppm -r 85 -png`
and every page was inspected visually. Rendered screenshots are retained
locally under `paper/build/archive-visual/final-{main,supp}-*.png` (not bundled).
Font embedding was checked separately by actual `pdffonts` output in
`REVIEW_PDF_PREFLIGHT.txt`; visual inspection alone is not a font test.

| PDF/page | Inspection |
| --- | --- |
| Main 1 | Title, author, ORCID, abstract and introduction fit; no clipping. |
| Main 2 | Evidence table and focused related-work discussion fit. |
| Main 3 | Scope/methods retain original controls and uncertainty boundaries. |
| Main 4 | Local-language table and Figure 1 readable in grayscale; edge markers inside frame. |
| Main 5 | Figure 2 uses 16–1024, retains upper headroom and horizontal padding; legend readable. CRC excerpt fits. |
| Main 6 | FP excerpt, profile table and FFT-count table fit; publication-facing language labels retained. |
| Main 7 | Figures 3/4 readable in grayscale; padded edge markers; SHA point/log overview and software zero-baseline detail retain exact values. |
| Main 8 | Discussion/limitations unchanged; availability explicitly limits package scope and says not deposited. Future work fits. |
| Main 9 | Conclusion and all 24 references fit; no dangling nearly-empty page. RISC-V capitalization preserved. |
| Supplement 1 | Reader map distinguishes supplied package and private evidence; limitations table fits. |
| Supplement 2 | Evidence/access map, 15-row historical/local matrix and reproduction contract fit; no nearly-empty extra page. |

Main: 9 pages. Supplement: 2 pages. No observed clipped markers, overlapping
labels or out-of-page tables. Horizontal plot padding is a presentation-only
change; values, vertical axes and scientific interpretations are unchanged.
This is an internal visual preflight, not external peer review.
